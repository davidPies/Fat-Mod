package overeatingmod;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;

public class ModelFatRef {
	public static ModelRenderer Shape1;
	public static ModelRenderer Shape2;
    public static int bellyFatModifier;
    public static final ResourceLocation Fat_CAP = new ResourceLocation(overeatingmod.MODID, "fat");
	public static EntityPlayer p;
	private static boolean isSmallArms;
	//public static final ModelFatRef INSTANCE = new ModelFatRef();
	public ModelFatRef(int bellyFat) {
		bellyFatModifier = bellyFat / 2;
	       // if(player.hasCapability(FatProvider.Fat_CAP, null))  bellyFatModifier = player.getCapability(FatProvider.Fat_CAP, null).getThickness();
	        if(bellyFatModifier > 15) {// && bellyFatModifier < 17) {
	      	  Shape1.addBox(0F, 0F, -4F - 1, 6, 5, 2 + 1);
	            
	      	  Shape2.addBox(-1F, -2F, -3F - 1, 8, 7, 1 + 1);
	        
	    	}else if(bellyFatModifier > 12 && bellyFatModifier < 16) {
	      	  Shape1.addBox(bellyFatModifier > 13? 0F: 1F, 0F, -4F, bellyFatModifier > 13? 6: 4, bellyFatModifier > 13? 5: 4, 2);
	            
	      	  Shape2.addBox(bellyFatModifier > 13? -1F: 0F, -2F, bellyFatModifier > 13? -3F: -3F, bellyFatModifier > 13? 8: 6, 7, 1);
	        }else if(bellyFatModifier > 8 && bellyFatModifier < 13){
	      	  Shape1.addBox(1F, 0F, -4F, 4, 5, 2);
	            
	      	  Shape2.addBox(0F, -1F, -3F, 6, 6, 1);
	        }else {
	      	  if(bellyFatModifier > 4 && bellyFatModifier < 9) {
	      		  Shape1.addBox(0F, 0F, 0F, 4, 5, 0);
	                
	      		  Shape2.addBox(0F, 0F, -3F, 6, 5, 2);
	      	  }else{
	      		  Shape1.addBox(0F, 0F, 0F, 4, 5, 0);
	      		  
	      		  Shape2.addBox(0F, 0F, 0F, 6, 5, 0);
	      	  }
	        }
	}
	public static void DefRef(EntityPlayer player, ModelPlayer modelBase, int bellyFat) {
		
	}
    public static void Ref(EntityPlayer player, ModelPlayer modelBase, int bellyFat)
    {
        bellyFatModifier = bellyFat / 2;
       // if(player.hasCapability(FatProvider.Fat_CAP, null))  bellyFatModifier = player.getCapability(FatProvider.Fat_CAP, null).getThickness();
        if(bellyFatModifier > 15) {// && bellyFatModifier < 17) {
      	  Shape1.addBox(0F, 0F, -4F - 1, 6, 5, 2 + 1);
            
      	  Shape2.addBox(-1F, -2F, -3F - 1, 8, 7, 1 + 1);
        
    	}else if(bellyFatModifier > 12 && bellyFatModifier < 16) {
      	  Shape1.addBox(bellyFatModifier > 13? 0F: 1F, 0F, -4F, bellyFatModifier > 13? 6: 4, bellyFatModifier > 13? 5: 4, 2);
            
      	  Shape2.addBox(bellyFatModifier > 13? -1F: 0F, -2F, bellyFatModifier > 13? -3F: -3F, bellyFatModifier > 13? 8: 6, 7, 1);
        }else if(bellyFatModifier > 8 && bellyFatModifier < 13){
      	  Shape1.addBox(1F, 0F, -4F, 4, 5, 2);
            
      	  Shape2.addBox(0F, -1F, -3F, 6, 6, 1);
        }else {
      	  if(bellyFatModifier > 4 && bellyFatModifier < 9) {
      		  Shape1.addBox(0F, 0F, 0F, 4, 5, 0);
                
      		  Shape2.addBox(0F, 0F, -3F, 6, 5, 2);
      	  }else{
      		  Shape1.addBox(0F, 0F, 0F, 4, 5, 0);
      		  
      		  Shape2.addBox(0F, 0F, 0F, 6, 5, 0);
      	  }
        }
    }
    private static void setRotation(ModelRenderer model, float x, float y, float z)
    {
      model.rotateAngleX = x;
      model.rotateAngleY = y;
      model.rotateAngleZ = z;
    }
    public static void render(ModelPlayer modelBase, EntityPlayer player) {
    	do {
    		if(player.hasCapability(FatProvider.Fat_CAP, null)) {
    			IFat fat = player.getCapability(FatProvider.Fat_CAP, null);
    			int bellyFatModifier = fat.getThickness();
    			Ref(player, modelBase, bellyFatModifier);
    		}else {
    			Ref(player, modelBase, 0);
    		}
    	}while(overeatingmod.logged == true);
    }
    public static void renderNonRepeat(ModelPlayer modelBase, EntityPlayer player) {
    		//if(player.hasCapability(FatProvider.Fat_CAP, null)) {
    			IFat fat = player.getCapability(FatProvider.Fat_CAP, null);
    			int bellyFatModifier = fat.getThickness();
    			//Ref(player, modelBase, bellyFatModifier);
    			new ModelFatRef(bellyFatModifier);
    			//if(modelBase.isChild) {
    				//GlStateManager.scale(0.5F, 0.5F, 0.5F);
    	           // GlStateManager.translate(0.0F, 24.0F * 0.0625f, 0.0F);
    			//}
    		//}else {
    		//	Ref(player, modelBase, 0);
    		//}
    }
	public static void renderShapes(ModelBase modelBase) {
        Shape1 = new ModelRenderer(modelBase, 17, 23);
        Shape2 = new ModelRenderer(modelBase, 17, 23);
        Shape1.setRotationPoint(-3F, 6F, 0F);
        Shape1.mirror = true;
        setRotation(Shape1, 0F, 0F, 0F);
        Shape2.setRotationPoint(-3F, 6F, 0F);
        Shape2.mirror = true;
        setRotation(Shape2, 0F, 0F, 0F);
	}
	public static void renderRepeatedShapes(ModelPlayer modelBase, EntityPlayer player) {
        Shape1 = new ModelRenderer(modelBase, 17, 23);
        Shape2 = new ModelRenderer(modelBase, 17, 23);
        int bellyFatModifier = player.getCapability(FatProvider.Fat_CAP, null).getThickness() / 2;
		//ModelFatRef.setFat(bellyFatModifier);
        renderNonRepeat(modelBase, player);
        Shape1.setRotationPoint(-3F, 6F, 0F);
        Shape1.mirror = true;
        setRotation(Shape1, 0F, 0F, 0F);
        Shape2.setRotationPoint(-3F, 6F, 0F);
        Shape2.mirror = true;
        setRotation(Shape2, 0F, 0F, 0F);
        //GlStateManager.pushMatrix();
		//ModelFatRef.Shape1.render(0.0625f);
		modelBase.bipedBody.addChild(Shape1);
		//ModelFatRef.Shape2.render(0.0625f);
		modelBase.bipedBody.addChild(Shape2);
		//GlStateManager.popMatrix();
	}
	public static void renderRepeatedShapes2(ModelPlayer modelBase) {
        Shape1 = new ModelRenderer(modelBase, 17, 23);
        Shape2 = new ModelRenderer(modelBase, 17, 23);
	}
	public static void renderRepeatedShapes3() {
        Shape1.setRotationPoint(-3F, 6F, 0F);
        Shape1.mirror = true;
        setRotation(Shape1, 0F, 0F, 0F);
        Shape2.setRotationPoint(-3F, 6F, 0F);
        Shape2.mirror = true;
        setRotation(Shape2, 0F, 0F, 0F);
	}
}
