package overeatingmod;

import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class SharedProxy {
		@EventHandler
	    public void preInit(FMLPreInitializationEvent event)
	    {
	    }

	    @EventHandler
	    public void init(FMLInitializationEvent event)
	    {
	    }
}
