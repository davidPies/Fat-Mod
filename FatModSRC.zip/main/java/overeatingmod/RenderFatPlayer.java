package overeatingmod;

import com.google.common.base.Predicate;

import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class RenderFatPlayer extends RenderPlayer{
	
	private static boolean isSmallArms;
	public static int thickness = 0;
	private RenderManager man;
	//public static ModelFat1 model = getModel(p, isSmallArms);
    public RenderFatPlayer(RenderManager renderManager)
    {
    	super(renderManager);
    	//p = player;
    	man = renderManager;
    }
    public void render(RenderManager renderManager) {
    	new RenderFatPlayer(renderManager);
    }
    public ModelFat1 getMainModel()
    {
    	//if(p != null) {
    	//if(!man.world.isRemote) {
    		for(EntityPlayer player : man.world.getPlayers(EntityPlayer.class, new Predicate<EntityPlayer>() {@Override public boolean apply(EntityPlayer input) {return true;}})) {
    	    		if(DefaultPlayerSkin.getSkinType(player.getUniqueID()).equals("slim")){
    	//if(super.getMainModel().bipedLeftArmwear.rotationPointY == 2.5F) {
    	    			isSmallArms = true;
    	    		}else {
    	    			isSmallArms = false;
    	    		}
    		}
    	//}
        return getModelNoPlayer(getT(), isSmallArms);//!man.world.isRemote ? getModel(man.world, getT(), isSmallArms) : getModelNoPlayer(getT(), isSmallArms);
    }
    public static ModelFat1 getModel(World world, int thickness2, boolean isSmallArms2)
    {
    	//PotionEffect effect1 = new PotionEffect(MobEffects.SLOWNESS, 60, 2);
    	//PotionEffect effect1 = new PotionEffect(Potion.getPotionById(2), 20, 2);
    	//PotionEffect effect2 = new PotionEffect(MobEffects.SLOWNESS, 60, 4);
    	//PotionEffect effect2 = new PotionEffect(Potion.getPotionById(2), 20, 4);
    	for(EntityPlayer player : world.getPlayers(EntityPlayer.class, new Predicate<EntityPlayer>() {@Override public boolean apply(EntityPlayer input) {return true;}})) {
    		
    		if(player.hasCapability(FatProvider.Fat_CAP, null)) {
    			return new ModelFat1(0, isSmallArms2, thickness2);
    		}else {
    			return new ModelFat1(0, isSmallArms2, 0);
    		}
    	}
		return new ModelFat1(0, isSmallArms2, thickness2);
    }
    public static ModelFat1 getModelNoPlayer(int thickness2, boolean isSmallArms2)
    {
    	return new ModelFat1(0, isSmallArms2, thickness2);
    }
    public ResourceLocation getEntityTexture(EntityPlayer entity)
    {
        return entity instanceof AbstractClientPlayer ? ((AbstractClientPlayer) entity).getLocationSkin() : new ResourceLocation(isSmallArms != true ? "textures/entity/steve.png": "textures/entity/alex.png");
    }
	public void doRender(AbstractClientPlayer entity, double x, double y, double z, float entityYaw, float partialTicks)
	{
		//super.doRender(entity, x, y, z, entityYaw, partialTicks);
		   GlStateManager.enableBlendProfile(GlStateManager.Profile.PLAYER_SKIN);
		this.getMainModel().render(entity, 1, 1, 1, entity.cameraYaw, entity.cameraPitch, partialTicks);
		  GlStateManager.disableBlendProfile(GlStateManager.Profile.PLAYER_SKIN);
	}
	public static int getT() {
		return thickness;
	}
	public void setT(int t) {
		thickness = t;
	}
	public void doRender(EntityPlayer entityPlayer) {
		 GlStateManager.enableBlendProfile(GlStateManager.Profile.PLAYER_SKIN);
			this.getMainModel().render(entityPlayer, 1, 1, 1, entityPlayer.cameraYaw, entityPlayer.cameraPitch, 0.1f);
			  GlStateManager.disableBlendProfile(GlStateManager.Profile.PLAYER_SKIN);
	}
}
