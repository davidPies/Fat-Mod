package overeatingmod;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public class ItemWeightPillCreative extends ItemWeightPill{
	public ItemWeightPillCreative() {
		
	}
	public String getItemStackDisplayName(ItemStack stack)
    {
		Minecraft mc = Minecraft.getMinecraft();
		if(mc.getLanguageManager().getCurrentLanguage().equals(mc.getLanguageManager().getLanguage("zh_cn"))) {
			return overeatingmod.getNewTranslation(8) + "(" + overeatingmod.getNewTranslation(9) + ")";//"减肥药 (创意模式)";
		}else {
			return "Weight Loss Pill (Creative Mode)";
		}
    }
	public String getName() {
		return "weightlosspillcreative";
	}
	public int getLossAmount(EntityPlayer player) {
		return player.getCapability(FatProvider.Fat_CAP, null).getThickness();
	}
	public int getStackDecreaseAmount() {
		return 0;
	}
}
