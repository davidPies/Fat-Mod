package overeatingmod;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

public class ItemWeightPill extends Item implements ISBRegistry{
	public ItemWeightPill() {
	}
	
	@Override
	public Item getItem() {
		return this;
	}

	@Override
	public Block getSBBlock() {
		return null;
	}
	
	public String getItemStackDisplayName(ItemStack stack)
    {
		Minecraft mc = Minecraft.getMinecraft();
		if(mc.getLanguageManager().getCurrentLanguage().equals(mc.getLanguageManager().getLanguage("zh_cn"))) {
			return overeatingmod.getNewTranslation(4); //"减肥药";
		}else {
			return "Weight Loss Pill";
		}
    }
	
	@Override
	public String getName() {
		return "weightlosspill";
	}
	public int getLossAmount(EntityPlayer player) {
		return 2;
	}
	public int getStackDecreaseAmount() {
		return 1;
	}
	public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn)
    {
		IFat fat = playerIn.getCapability(FatProvider.Fat_CAP, null);
		//overeatingmod.oneCount = 0;
		playerIn.getHeldItem(handIn).setCount(playerIn.getHeldItem(handIn).getCount() - getStackDecreaseAmount());
		if(fat.getThickness() > 0) {
			fat.removeThickness(getLossAmount(playerIn));
		}else if(fat.getThickness() >= 0 && this instanceof ItemWeightGainPillCreative) {
			fat.removeThickness(getLossAmount(playerIn));
		}else if(this instanceof ItemWeightPillCreative) {
			fat.removeThickness(getLossAmount(playerIn));
		}
        return new ActionResult<ItemStack>(EnumActionResult.SUCCESS, playerIn.getHeldItem(handIn));
    }
}
