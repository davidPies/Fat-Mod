package overeatingmod;

import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumHandSide;

public class ModelFat1 extends ModelPlayer
{
    ModelRenderer Shape1;
    ModelRenderer Shape2;
    ModelRenderer lleg;
    ModelRenderer rleg;
    ModelRenderer larm;
    ModelRenderer rarm;
    public int scale = 0;
    public int mod1 = 0;
    public int mod2 = 0;
    public int mod3 = 0;
    public static int bellyFatModifier;
  public ModelFat1(float modelSize, boolean smallArmsIn, int bellyFat)
  {
	super(modelSize, smallArmsIn);
	this.isChild = false;
      Shape1 = new ModelRenderer(this, 17, 23);
      Shape2 = new ModelRenderer(this, 17, 23);
      //larm = bipedLeftArm;

      lleg = new ModelRenderer(this, 16, 48);
      rleg = new ModelRenderer(this, 0, 16);
      larm = new ModelRenderer(this, 32, 48);
	  rarm = new ModelRenderer(this, 40, 16);
      //rarm = new ModelRenderer(this, 17, 23);
      bellyFatModifier = bellyFat / 2;
      //if(bellyFatModifier == 0){
    //	  mod1 = -1;
      //}else if(bellyFatModifier == 1){
    	//  
      //}
      //Shape1.addBox(0F, 0F - mod1, bellyFatModifier > 3? -1F: -2F - bellyFatModifier + mod2, 6, 4 + mod1, bellyFatModifier > 3? 2: 0 + bellyFatModifier);
      //while(bellyFatModifier < 4);
      //Shape1.addBox(0F, 0F - mod1, -2F - bellyFatModifier + mod2, 6, 4 + mod1, 0 + bellyFatModifier);
      if(bellyFatModifier > 32) {// && bellyFatModifier < 17) {
    	  int modifiedFat = 0;//bellyFatModifier - 33;
    	  Shape1.addBox(0F, 0F, -4F - 1 - modifiedFat, 6, 5, 2 + 1 + modifiedFat);
    	  if (smallArmsIn)
          {	
    		  this.larm.addBox(0.5F, -2.0F, -2.0F, 3, 12, 4, 1.6f);
			  this.rarm.addBox(-3.5F, -2.0F, -2.0F, 3, 12, 4, 1.6f);
			  this.lleg.addBox(-0.5F, 0.0F, -2.0F, 4, 12, 4, 1.6f);
        	  this.rleg.addBox(-3.5F, 0.0F, -2.0F, 4, 12, 4, 1.6f);
          }else {
    		  this.larm.addBox(0.5F, -2.0F, -2.0F, 4, 12, 4, 1.6f);
    		  this.rarm.addBox(-4.5F, -2.0F, -2.0F, 4, 12, 4, 1.6f);
    		  this.lleg.addBox(-0.5F, 0.0F, -2.0F, 4, 12, 4, 1.6f);
    		  this.rleg.addBox(-3.5F, 0.0F, -2.0F, 4, 12, 4, 1.6f);
          }
    	  //this.bipedLeftArm.addBox(-1, -2, -2, 6, 12, 4);
          //this.bipedRightArm.addBox(-5, -2, -2, 6, 12, 4);
         // this.bipedLeftLeg.addBox(-2, 0, -2, 6, 12, 4);
          //this.bipedRightLeg.addBox(-4, 0, -2, 6, 12, 4);
    	  Shape2.addBox(-1F, -2F, -3F - 1 - modifiedFat, 8, 7, 1 + 1 + modifiedFat);
  	  }else if(bellyFatModifier > 28 && bellyFatModifier < 33) {
    	  Shape1.addBox(bellyFatModifier > 13? 0F: 1F, 0F, -4F, bellyFatModifier > 13? 6: 4, bellyFatModifier > 13? 5: 4, 2);
    	  //this.bipedLeftArm.addBox(-1, -2, -2, 5, 12, 4);
          //this.bipedRightArm.addBox(-4, -2, -2, 5, 12, 4);
          //this.bipedLeftLeg.addBox(-2, 0, -2, 5, 12, 4);
          //this.bipedRightLeg.addBox(-3, 0, -2, 5, 12, 4);
    	  if (smallArmsIn)
          {	
    		  this.larm.addBox(0.0F, -2.0F, -2.0F, 3, 12, 4, 1.01f);
			  this.rarm.addBox(-3.0F, -2.0F, -2.0F, 3, 12, 4, 1.01f);
			  this.lleg.addBox(-1.0F, 0.0F, -2.0F, 4, 12, 4, 1.01f);
        	  this.rleg.addBox(-3.0F, 0.0F, -2.0F, 4, 12, 4, 1.01f);
          }else {
        	  this.larm.addBox(0.0F, -2.0F, -2.0F, 4, 12, 4, 1.01f);
        	  this.rarm.addBox(-4.0F, -2.0F, -2.0F, 4, 12, 4, 1.01f);
        	  this.lleg.addBox(-1.0F, 0.0F, -2.0F, 4, 12, 4, 1.01f);
        	  this.rleg.addBox(-3.0F, 0.0F, -2.0F, 4, 12, 4, 1.01f);
          }
    	  Shape2.addBox(bellyFatModifier > 13? -1F: 0F, -2F, bellyFatModifier > 13? -3F: -3F, bellyFatModifier > 13? 8: 6, 7, 1);
      }else if(bellyFatModifier > 24 && bellyFatModifier < 29){
    	  Shape1.addBox(1F, 0F, -4F, 4, 5, 2);
    	  if (smallArmsIn)
          {	
    		  this.larm.addBox(-0.5F, -2.0F, -2.0F, 3, 12, 4, 0.6f);
			  this.rarm.addBox(-2.5F, -2.0F, -2.0F, 3, 12, 4, 0.6f);
			  this.lleg.addBox(-1.5F, 0.0F, -2.0F, 4, 12, 4, 0.6f);
        	  this.rleg.addBox(-2.5F, 0.0F, -2.0F, 4, 12, 4, 0.6f);
          }else {
        	  this.larm.addBox(-0.5F, -2.0F, -2.0F, 4, 12, 4, 0.6f);
        	  this.rarm.addBox(-3.5F, -2.0F, -2.0F, 4, 12, 4, 0.6f);
        	  this.lleg.addBox(-1.5F, 0.0F, -2.0F, 4, 12, 4, 0.6f);
        	  this.rleg.addBox(-2.5F, 0.0F, -2.0F, 4, 12, 4, 0.6f);
          }
    	  
    	  Shape2.addBox(0F, -1F, -3F, 6, 6, 1);
      }else {
    	  if(bellyFatModifier > 20 && bellyFatModifier < 25) {
    		  Shape1.addBox(0F, 0F, 0F, 4, 5, 0);
    		  if (smallArmsIn)
              {	
    			  this.larm.addBox(-1.0F, -2.0F, -2.0F, 3, 12, 4, 0f);
    			  this.rarm.addBox(-2.0F, -2.0F, -2.0F, 3, 12, 4, 0f);
    			  this.lleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0f);
            	  this.rleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0f);
              }else {
            	  this.larm.addBox(-1.0F, -2.0F, -2.0F, 4, 12, 4, 0f);
            	  this.rarm.addBox(-3.0F, -2.0F, -2.0F, 4, 12, 4, 0f);
            	  this.lleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0f);
            	  this.rleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0f);
              }
    		  Shape2.addBox(0F, 0F, -3F, 6, 5, 2);
    	  }else{
    		  Shape1.addBox(0F, 0F, 0F, 4, 5, 0);
    		  if (smallArmsIn)
              {	
    			  this.larm.addBox(-1.0F, -2.0F, -2.0F, 3, 12, 4, 0f);
    			  this.rarm.addBox(-2.0F, -2.0F, -2.0F, 3, 12, 4, 0f);
    			  this.lleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0f);
            	  this.rleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0f);
              }else {
            	  this.larm.addBox(-1.0F, -2.0F, -2.0F, 4, 12, 4, 0f);
            	  this.rarm.addBox(-3.0F, -2.0F, -2.0F, 4, 12, 4, 0f);
    			  this.lleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0f);
            	  this.rleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0f);
              }
        	  
    		  Shape2.addBox(0F, 0F, 0F, 6, 5, 0);
    	  }
    	  //Shape1.addBox(0F, 0F, bellyFatModifier == 3? 0F: 0F, 4, 5, bellyFatModifier == 3? 0: 0);
          
    	 // Shape2.addBox(0F, 0F, bellyFatModifier == 3? -3F: 0F, 6, 5, bellyFatModifier == 3? 2: 0);
      
      }
      Shape1.setRotationPoint(-3F, 6F, 0F);
      Shape1.mirror = true;
      setRotation(Shape1, 0F, 0F, 0F);
      
      
      lleg.setRotationPoint(1.9F, 12.0F, 0.0F);
      lleg.mirror = true;
      //setRotation(lleg, 0F, 0F, 0F);
     
      rleg.setRotationPoint(-1.9F, 12.0F, 0.0F);
      rleg.mirror = true;
      
      larm.setRotationPoint(5.0F, 2.0F, 0.0F);
      larm.mirror = true;
      setRotation(larm, 0F, 0F, 0F);
      
      rarm.setRotationPoint(-5.0F, 2.0F, 0.0F);
      rarm.mirror = true;
      setRotation(rarm, 0F, 0F, 0F);
      
      Shape2.setRotationPoint(-3F, 6F, 0F);
      Shape2.mirror = true;
      setRotation(Shape2, 0F, 0F, 0F);
      
      this.bipedLeftArm = larm;
      this.bipedRightArm = rarm;
      this.bipedLeftLeg = lleg;
      this.bipedRightLeg = rleg;
  }
  protected ModelRenderer getArmForSide(EnumHandSide side)
  {
      return side == EnumHandSide.LEFT ? this.larm : this.rarm;
  }
  public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5)
  {
    super.render(entity, f, f1, f2, f3, f4, f5);
    setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    Shape1.render(f5);
    this.bipedBody.addChild(Shape1);
    Shape2.render(f5);
    this.bipedBody.addChild(Shape2);
    
    this.bipedLeftLegwear.render(f5);
    this.bipedRightLegwear.render(f5);
    this.bipedLeftArmwear.render(f5);
    this.bipedRightArmwear.render(f5);
    this.bipedBodyWear.render(f5);
    
  }
  
  private void setRotation(ModelRenderer model, float x, float y, float z)
  {
    model.rotateAngleX = x;
    model.rotateAngleY = y;
    model.rotateAngleZ = z;
  }
  
  public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity)
  {
    super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
  }
  public float getScale() {
	  return this.scale;
  }
}
