package overeatingmod;

import java.io.IOException;

import net.minecraft.client.Minecraft;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;

public class Tabs {
	public static CreativeTabs Item = new CreativeTabs("fuditems") {
		@Override
		public ItemStack getTabIconItem() {
			return new ItemStack(overeatingmod.items[0].getItem());
		}
		public String getTranslatedTabLabel()
	    {
			//Minecraft mc = Minecraft.getMinecraft();
			//if(mc.getLanguageManager().getCurrentLanguage().equals(mc.getLanguageManager().getLanguage("zh_cn"))) {
				//return overeatingmod.getNewTranslation(0);
			//}else {
				return "Dave's Overweight Mod";
			//}
	    }
	};
}
