package overeatingmod;

public interface IFat {

	public int getThickness();
	public void addThickness(int levelToAdd);
	public void removeThickness(int levelToRemove);
	public void setThickness(int levelToSet);
}
