package overeatingmod;

import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class Client extends SharedProxy{
	public void preInit(FMLPreInitializationEvent event)
    {
    }
    public void init(FMLInitializationEvent event)
    {
    }
}
