package overeatingmod;

import javax.annotation.Nullable;

import net.minecraft.block.Block;
import net.minecraft.item.Item;

public interface ISBRegistry {
	@Nullable
	Item getItem();
	
	@Nullable
	Block getSBBlock();
	
	String getName();
}
