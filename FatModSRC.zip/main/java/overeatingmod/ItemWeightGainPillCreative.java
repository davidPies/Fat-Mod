package overeatingmod;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public class ItemWeightGainPillCreative extends ItemWeightPillCreative{
	public ItemWeightGainPillCreative() {
		
	}
	public String getItemStackDisplayName(ItemStack stack)
    {
		Minecraft mc = Minecraft.getMinecraft();
		if(mc.getLanguageManager().getCurrentLanguage().equals(mc.getLanguageManager().getLanguage("zh_cn"))) {
			return overeatingmod.getNewTranslation(5) + ": 5 " + overeatingmod.getNewTranslation(6) + "(" + overeatingmod.getNewTranslation(7) + ")";// 水平 (创意模式)";
		}else {
			return "Weight Gain Pill: 5 levels (Creative Mode)";
		}
    }
	public String getName() {
		return "weightgainpillcreative";
	}
	public int getLossAmount(EntityPlayer player) {
		return -5;
	}
}