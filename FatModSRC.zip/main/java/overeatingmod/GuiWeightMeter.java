package overeatingmod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class GuiWeightMeter extends Gui{
	String text;
	String text2;
    public GuiWeightMeter(Minecraft mc)
    {
    	if(mc.getLanguageManager().getCurrentLanguage().equals(mc.getLanguageManager().getLanguage("zh_cn"))) {
    		text = overeatingmod.getNewTranslation(1) + " " + mc.player.getCapability(FatProvider.Fat_CAP, null).getThickness() / 2 + " / 40";
    		text2 = overeatingmod.getNewTranslation(2) + " " + mc.player.getFoodStats().getSaturationLevel() + "  " + overeatingmod.getNewTranslation(3) + overeatingmod.jumpCount;
    	}else {
    		text = "Weight Level: " + mc.player.getCapability(FatProvider.Fat_CAP, null).getThickness() / 2 + " / 40";
    		text2 = "Saturation Level: " + mc.player.getFoodStats().getSaturationLevel() + "  Jumping jacks: " + overeatingmod.jumpCount;
    	}
    	ScaledResolution scaled = new ScaledResolution(mc);
        int width = scaled.getScaledWidth();
        int height = scaled.getScaledHeight();
        drawCenteredString(mc.fontRenderer, text, width / 2, (height * 3 / 4) - 10, 0xaf4b11);
        drawCenteredString(mc.fontRenderer, text2, width / 2, (height * 3 / 4) - 25, 0xaf4b11);
    }
}
