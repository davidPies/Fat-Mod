package overeatingmod;

public class CFat implements IFat{
	public static int thickness = 0;
	
	@Override
	public int getThickness() {
		return thickness;
	}

	@Override
	public void addThickness(int levelToAdd) {
		if(thickness < 80)
			thickness = thickness + levelToAdd;
		
	}

	@Override
	public void removeThickness(int levelToRemove) {
		if(thickness <= 70 && levelToRemove == -10) {
			thickness = thickness - levelToRemove;
		}else if(thickness <= 75 && levelToRemove == -5){
			thickness = thickness - levelToRemove;
		}else if(thickness <= 80 && thickness > 70 && (levelToRemove == -5 || levelToRemove == -10)) {
			thickness = 80;
		}
		else if(thickness <= 80 && levelToRemove > 0) {
			thickness = thickness - levelToRemove;
		}
	}

	@Override
	public void setThickness(int levelToSet) {
		if(levelToSet <= 80) {
			thickness = levelToSet;
		}else {
			thickness = 80;
		}
	}

}
