package overeatingmod;

import com.google.common.base.Predicate;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayer.SleepResult;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingKnockBackEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.RightClickItem;
import net.minecraftforge.event.entity.player.PlayerSleepInBedEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedOutEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = overeatingmod.MODID, name = overeatingmod.NAME, version = overeatingmod.VERSION, acceptedMinecraftVersions = "1.12.2", clientSideOnly = true)
@Mod.EventBusSubscriber(modid = overeatingmod.MODID)
public class overeatingmod
{
    public static final String MODID = "overeatingmod";
    public static final String NAME = "Overeating Mod (Chunk 1/2)";
    public static final String VERSION = "1.9";
    
    public static ISBRegistry[] items = new ISBRegistry[]{new ItemWeightPill(), new ItemWeightPillCreative(), new ItemWeightGainPillCreative()};
    	
    private RenderFatPlayer3 render;
  //  @SidedProxy(clientSide="overeatingmod.Client", serverSide="overeatingmod.Server")
//    public static SharedProxy proxy;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event)
    {
    	CapabilityManager.INSTANCE.register(IFat.class, new FatStorage(), CFat::new);
    	//MinecraftServer s;
    }

    @EventHandler
    public void init(FMLInitializationEvent event)
    {
    	//RenderingRegistry.registerEntityRenderingHandler(AbstractClientPlayer.class, renderManager -> new RenderFatPlayer1(Minecraft.getMinecraft().getRenderManager()));
        
    	//RenderingRegistry.registerEntityRenderingHandler(AbstractClientPlayer.class, renderManager -> new RenderFatPlayer1(Minecraft.getMinecraft().getRenderManager()));
    	GameRegistry.addShapedRecipe(new ResourceLocation(this.MODID, "cwp"), null, new ItemStack(items[0].getItem(), 4, 0), new Object[]{"f  ", " f ", "  i", 'f', Items.FEATHER, 'i', Items.GLASS_BOTTLE});
    	//GameRegistry.addShapelessRecipe(new ResourceLocation(overeatingmod.MODID, "csbmatch"), null, new ItemStack(items[1].getItem(), 6, 0), Ingredient.fromItem(Items.STICK), Ingredient.fromStacks(new ItemStack(Items.COAL, 1, 0)), Ingredient.fromItem(Items.FLINT));
    	MinecraftForge.EVENT_BUS.register(this);
    	MinecraftForge.EVENT_BUS.register(new Client());
    }
    @SubscribeEvent	
	public static void registryIEvent(RegistryEvent.Register<Item> e) {
		for(int i = 0; i < items.length; i++) {
			//if(!(i == 0) && !(i == 4) && !(i == 5) && !(i == 6)) {
				addItem(items[i]);
				e.getRegistry().register(items[i].getItem());
			//}
		}
		//e.getRegistry().register(items[0].getItem());
		//e.getRegistry().register(items[4].getItem());
		//e.getRegistry().register(items[5].getItem());
		//e.getRegistry().register(items[6].getItem());
	}
   // @SubscribeEvent	
	//public static void registryBEvent(RegistryEvent.Register<Block> e) {
		//e.getRegistry().register(Block.getBlockFromItem(items[0].getItem()));
	//	e.getRegistry().register(Block.getBlockFromItem(items[4].getItem()));
	//	e.getRegistry().register(Block.getBlockFromItem(items[5].getItem()));
		//e.getRegistry().register(Block.getBlockFromItem(items[6].getItem()));
	//}
    @SubscribeEvent	
    public static void modelEvent(ModelRegistryEvent e) {
		for(int i = 0; i < items.length; i++) {
			addTexure(items[i]);
		}
	}
	private static void addTexure(ISBRegistry item) {
			//for(int i = 0; i < 2; i++)
				//if(item == items[6]) {
				//	ModelLoader.setCustomModelResourceLocation(item.getItem(), i, new ModelResourceLocation("minecraft" + ":" + "grass", "inventory"));
				//}
				//else {
					ModelLoader.setCustomModelResourceLocation(item.getItem(), 0, new ModelResourceLocation(MODID + ":" + item.getName(), "inventory"));
				//}
	}
	public static void addItem(ISBRegistry reg) {
		reg.getItem().setCreativeTab(Tabs.Item);
		reg.getItem().setUnlocalizedName(reg.getName());
		reg.getItem().setRegistryName(overeatingmod.MODID, reg.getName());
	}
    public static void addNormalBlock(ISBRegistry reg) {
		reg.getSBBlock().setCreativeTab(Tabs.Item);
		reg.getSBBlock().setUnlocalizedName(reg.getName());
		reg.getSBBlock().setRegistryName(overeatingmod.MODID, reg.getName());
	}
    public static void addNonNormalBlock(ISBRegistry reg) {
		reg.getSBBlock().setCreativeTab(Tabs.Item);
		reg.getSBBlock().setUnlocalizedName(reg.getName());
	}
    @SubscribeEvent	
	public static void itemClickEvent(RightClickItem e) {
    	//if(e.getItemStack().getItem() instanceof ItemHoe) {
    	//	IFat fat = e.getEntityPlayer().getCapability(FatProvider.Fat_CAP, null);
    		//fat.setThickness(0);
    		//if(!e.getWorld().isRemote){
    		//	e.getEntityPlayer().removePotionEffect(MobEffects.SLOWNESS);
    	//	}
    	//}else
    		if(e.getItemStack().getItem() instanceof ItemFood) {
    		((ItemFood)e.getItemStack().getItem()).setAlwaysEdible();
    	//
    		}
    	//else if(e.getItemStack().getItem() instanceof ItemArmor) {
    	//	e.getEntityPlayer().inventory.armorInventory.clear();
    	//	//((ItemArmor)e.getItemStack().getItem()).is
    	//}
    }
    @SubscribeEvent	
	public static void itemUseEvent(LivingEntityUseItemEvent.Finish e) {
    	if(e.getItem().getItem() instanceof ItemFood) {
    		if(e.getEntityLiving() instanceof EntityPlayer) {
    			IFat fat = e.getEntityLiving().getCapability(FatProvider.Fat_CAP, null);
    			if(((EntityPlayer)e.getEntityLiving()).getFoodStats().needFood() == false) {
    				fat.addThickness(1);
    				if(((ItemFood)e.getItem().getItem()).getSaturationModifier(e.getItem()) > 0.8F && (fat.getThickness() / 2) > 8)
    				((EntityPlayer)e.getEntityLiving()).getFoodStats().setFoodSaturationLevel(((EntityPlayer)e.getEntityLiving()).getFoodStats().getSaturationLevel() - 0.45F);
    				oneCount = 0;
    			}
    		//}else if(e.getEntityLiving() instanceof AbstractClientPlayer) {// todo:  bias by saturation
    		//	IFat fat = e.getEntityLiving().getCapability(FatProvider.Fat_CAP, null);
    			//if(((AbstractClientPlayer)e.getEntityLiving()).getFoodStats().needFood() == false) {
    			//	fat.addThickness(1);
    				//oneCount = 0;
    			//}
    		}
    	}
    }
    @SubscribeEvent
	public void onKnockBack(LivingKnockBackEvent e)
	{
    	if(e.getEntityLiving() instanceof EntityPlayer) {
    		IFat fat = e.getEntityLiving().getCapability(FatProvider.Fat_CAP, null);
    		if((fat.getThickness() / 2) > 12) {
    			e.setStrength(e.getOriginalStrength() - 0.25F);
    		}else if((fat.getThickness() / 2) > 8 && (fat.getThickness() / 2) < 13) {
    			e.setStrength(e.getOriginalStrength() - 0.15F);
    		}
    	}
	}
    @SubscribeEvent
	public void onFall(LivingFallEvent e)
	{
    	if(e.getEntityLiving() instanceof EntityPlayer) {
    		IFat fat = e.getEntityLiving().getCapability(FatProvider.Fat_CAP, null);
    		if((fat.getThickness() / 2) > 12) {
    			e.setDamageMultiplier(e.getDamageMultiplier() + 0.75F);
    		}else if((fat.getThickness() / 2) > 8 && (fat.getThickness() / 2) < 13) {
    			e.setDamageMultiplier(e.getDamageMultiplier() + 0.5F);
    		}
    	}
	}
    @SubscribeEvent
    public void onRenderGui(RenderGameOverlayEvent.Post e)
    {
    	if(e.getType() != ElementType.ALL)// {
    		return;// && e.getType() != ElementType.ALL)
    	//}else if(e.getType() != ElementType.ARMOR) {
    		//return;
    	//}else{
    		new GuiWeightMeter(Minecraft.getMinecraft());
    	//}
    }
	public static final ResourceLocation Fat_CAP = new ResourceLocation(MODID, "fat");
	
	@SubscribeEvent
	public void attachCapability(AttachCapabilitiesEvent<Entity> event)
	{
		if (!(event.getObject() instanceof EntityPlayer)) return;
			
		event.addCapability(Fat_CAP, new FatProvider());
	}
	@SubscribeEvent
	public void onPlayerClone(PlayerEvent.Clone event)
	{
		if(event.getEntityPlayer() instanceof EntityPlayer) {
			EntityPlayer player = (EntityPlayer) event.getEntityPlayer();
			IFat fat = player.getCapability(FatProvider.Fat_CAP, null);
			fat.setThickness(0);
		}
	}
	static int oneCount = 0;
	@SubscribeEvent
	public void onPlayerSleep(PlayerSleepInBedEvent event)
	{
		if(event.getEntityPlayer() instanceof EntityPlayer) {
			IFat fat = event.getEntityPlayer().getCapability(FatProvider.Fat_CAP, null);
			if(event.getResultStatus() == SleepResult.OK)
			fat.removeThickness(2);
		}
		//sleepCount = sleepCount + 1;
		//if(sleepCount > 3){
			//sleepCount = 0;
			//fat.addThickness(1);
		//}
	}
	public static boolean logged = false;
	@SubscribeEvent
	public void onPlayerLoggin(PlayerLoggedInEvent event)
	{
		Count2 = 0;
		Count3 = 0;
		logged = true;
		//sleepCount = 0;
		IFat fat = event.player.getCapability(FatProvider.Fat_CAP, null);
		//if(fat.getThickness() > 40) fat.setThickness(40);
		//event.player.removePotionEffect(MobEffects.SLOWNESS);
		//do {
		//	if((fat.getThickness() / 2) < 6) {
		//	event.player.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 60, 1));//PotionTypes.SLOWNESS);
		//	}
		//	else {
		//	}
		//}while(logged == true && (fat.getThickness()/ 2) > 0);
		//fat.setThickness(10);
	}
	@SubscribeEvent
	public void onPlayerLoggout(PlayerLoggedOutEvent event)
	{
		logged = false;
		IFat fat = event.player.getCapability(FatProvider.Fat_CAP, null);
		//fat.setThickness(0);
	}
	//@SideOnly(Side.CLIENT)
	@SubscribeEvent	
	public void renderEvent(RenderPlayerEvent.Pre e) {
		//if(e.getEntityPlayer() instanceof AbstractClientPlayer) {
		if (!(e.getEntity() instanceof EntityPlayer)) return;
			e.setCanceled(true);
			//ModelFatRef.renderShapes(e.getRenderer().getMainModel());
			//if(!e.getEntityPlayer().isServerWorld()){if(e.getEntityPlayer() instanceof AbstractClientPlayer) {
				render = new RenderFatPlayer3(e.getRenderer().getRenderManager(), e.getEntityPlayer());
				//render.render(e.getRenderer().getRenderManager());
				
				//render.doRender(e.getEntityPlayer());
				render.doRender(e.getEntityPlayer(), e.getX(), e.getY(), e.getZ(), e.getEntityPlayer().rotationYawHead, e.getPartialRenderTick());
			
				
				//}	}//GlStateManager.pushMatrix();
			//ModelFatRef.Shape1.render(0.0625f);
			//e.getRenderer().getMainModel().bipedBody.addChild(ModelFatRef.Shape1);
			//ModelFatRef.Shape2.render(0.0625f);
			//e.getRenderer().getMainModel().bipedBody.addChild(ModelFatRef.Shape2);
			//GlStateManager.popMatrix();
			//model = e.getRenderer().getMainModel();
			//ModelFatRef.render(e.getRenderer().getMainModel(), e.getEntityPlayer());
			//if(!e.getEntityPlayer().getEntityWorld().isRemote)ModelFatRef.render(e.getRenderer().getMainModel(), e.getEntityPlayer());
			//}
			//new RenderFatPlayer1(e.getRenderer().getRenderManager(), e.getEntityPlayer()).doRender(e.getEntityPlayer(), 0, 0, 0, 0, 0.0625f);
	}
	//@SubscribeEvent	
	public void renderEvent(RenderHandEvent e) {
		//e.setCanceled(true);
		//if(render !=null)render.renderRightArm(3.0f);
	}
	static int jumpCount = 0;
	int Count = 0;
	int time = 0;
	@SubscribeEvent
	public void tick(TickEvent.PlayerTickEvent e) {
		PotionEffect effect1 = new PotionEffect(MobEffects.SLOWNESS, 40, 0);
    	PotionEffect effect2 = new PotionEffect(MobEffects.SLOWNESS, 40, 1);
    	PotionEffect effect3 = new PotionEffect(MobEffects.SLOWNESS, 40, 2);
    	
    	PotionEffect effect4 = new PotionEffect(MobEffects.ABSORPTION, 500, 0);
    	PotionEffect effect5 = new PotionEffect(MobEffects.ABSORPTION, 600, 1);
    	//for(EntityPlayer player : e.player.world.getPlayers(EntityPlayer.class, new Predicate<EntityPlayer>() {@Override public boolean apply(EntityPlayer input) {return true;}})) {
			if(e.player.hasCapability(FatProvider.Fat_CAP, null)) {
				IFat fat = e.player.getCapability(FatProvider.Fat_CAP, null);
				if(e.side == Side.CLIENT) if(render != null) render.setT(fat.getThickness());
			}
    	//}
    	if(overeatingmod.logged == true){
    		for(EntityPlayer player : e.player.world.getPlayers(EntityPlayer.class, new Predicate<EntityPlayer>() {@Override public boolean apply(EntityPlayer input) {return true;}})) {
    			if(player.hasCapability(FatProvider.Fat_CAP, null)) {
    				IFat fat = player.getCapability(FatProvider.Fat_CAP, null);
    				int bellyFatModifier = fat.getThickness();
    				//if(render != null) render.thickness = bellyFatModifier / 2;
    				if((bellyFatModifier / 2) > 0){
    					if(player.isAirBorne == true && Count == 0) {
    						jumpCount = jumpCount + 1;
    						//t.scheduleAtFixedRate(tt, 1000l, 1000l);
    						Count = 1;
    					}
    					if(player.isAirBorne == false) {
    						//time = 0;
    						Count = 0;
    					}
    					if(jumpCount == 20) {
    						fat.removeThickness(2);
    						jumpCount = 0;
    					}
    				}
    				if((bellyFatModifier / 2) > 12) {
    					player.addPotionEffect(effect3);
    					if(oneCount == 0) {
    						player.addPotionEffect(effect5);
    						oneCount = 1;
    					}
    					if(player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() != null){
							player.addItemStackToInventory(player.getItemStackFromSlot(EntityEquipmentSlot.CHEST));
							player.setItemStackToSlot(EntityEquipmentSlot.CHEST, ItemStack.EMPTY);
						}
    					if(player.isRiding())
    						player.dismountRidingEntity();
    					//for(int i = 0; 4 > i; i++) {
    						//if(!(player.inventory.armorInventory.get(i) == ItemStack.EMPTY) && !player.inventory.armorInventory.contains(null)) {
    						//	player.dropItem(player.inventory.armorInventory.get(i).getItem(), 1);
    							//player.inventory.mainInventory.add(player.inventory.armorInventory.get(i));
    	    					//player.inventory.armorInventory.remove(i);
    						//}
    					//}
    				}else if((bellyFatModifier / 2) > 8 && (bellyFatModifier / 2) < 13) {
    					player.addPotionEffect(effect2);
    					if(oneCount == 0) {
    						player.addPotionEffect(effect4);
    						oneCount = 1;
    					}
    					if(player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() != null){
							player.addItemStackToInventory(player.getItemStackFromSlot(EntityEquipmentSlot.CHEST));
							player.setItemStackToSlot(EntityEquipmentSlot.CHEST, ItemStack.EMPTY);
						}
    					if(player.isRiding())
    						player.dismountRidingEntity();
    				}else if((bellyFatModifier / 2) > 5 && (bellyFatModifier / 2) < 9) {
    					player.addPotionEffect(effect1);
    					if(player.isRiding())
    						player.dismountRidingEntity();
    				}else {
    					player.removePotionEffect(MobEffects.SLOWNESS);
    					player.removePotionEffect(MobEffects.ABSORPTION);
    				}
    			}
			}
    	}
	}
	//IFat fat = null;
	int Count2 = 0;
	int Count3 = 0;
	//ModelFatRef.Ref(renderplayer.getMainModel(), bellyFatModifier);
	public static String getNewTranslation(int lineNumber){
		//String in = overeatingmod.class.getResource("lang.json").getPath();
		//String[] s = null;
		//FileReader fr = null;
		//try {
		//	fr = new FileReader(in);
		//} catch (FileNotFoundException e1) {
		//	e1.printStackTrace();
		//}
		//try {
		//	char[] i = new char[60];
		//	fr.read(i);
			//for(char c : i) {
			//s = String.valueOf(i).split(" ");
		//	System.out.println(s[0]);
			//}
			//String[] s = fr.readLines(in, StandardCharsets.UTF_16).get(0).split(" ");
			return "bad translations, fix soon";
	//	} catch (IOException e) {
	//		e.printStackTrace();
	//	}
		//return null;
	}
}
