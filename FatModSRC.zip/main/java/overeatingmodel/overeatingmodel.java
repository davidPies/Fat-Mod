package overeatingmodel;

import com.google.common.base.Predicate;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingKnockBackEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.RightClickItem;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedOutEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import overeatingmod.FatProvider;
import overeatingmod.IFat;

@Mod(modid = overeatingmodel.MODID, name = overeatingmodel.NAME, version = overeatingmodel.VERSION, acceptedMinecraftVersions = "1.12.2")//, serverSideOnly = true)
public class overeatingmodel
{
    public static final String MODID = "overeatingmodel";
    public static final String NAME = "The Overeating Mod (Chunk 2/2)";
    public static final String VERSION = "1.9";
    
//    @SidedProxy(clientSide="overeatingmod.Client", serverSide="overeatingmod.Server")
  //  public static SharedProxy proxy;
    			//5316
    @EventHandler
    public void preInit(FMLPreInitializationEvent event)
    {
    }

    @EventHandler
    public void init(FMLInitializationEvent event)
    {
    	MinecraftForge.EVENT_BUS.register(this);
    }
	static int oneCount = 0;
	public static boolean logged = false;
	@SubscribeEvent
	public void onPlayerLoggin(PlayerLoggedInEvent event)
	{
		logged = true;
	}
	@SubscribeEvent
	public void onPlayerLoggout(PlayerLoggedOutEvent event)
	{
		logged = false;
	}
	static int jumpCount = 0;
	int Count = 0;
	@SubscribeEvent
	public void tick(TickEvent.WorldTickEvent e) {
		PotionEffect effect1 = new PotionEffect(MobEffects.SLOWNESS, 40, 0);
    	PotionEffect effect2 = new PotionEffect(MobEffects.SLOWNESS, 40, 1);
    	PotionEffect effect3 = new PotionEffect(MobEffects.SLOWNESS, 40, 2);
    	
    	PotionEffect effect4 = new PotionEffect(MobEffects.ABSORPTION, 500, 0);
    	PotionEffect effect5 = new PotionEffect(MobEffects.ABSORPTION, 600, 1);
    	if(overeatingmodel.logged == true) {//&& !e.world.isRemote){
    		for(EntityPlayer player : e.world.getPlayers(EntityPlayer.class, new Predicate<EntityPlayer>() {@Override public boolean apply(EntityPlayer input) {return true;}})) {
    			if(player.hasCapability(FatProvider.Fat_CAP, null)) {
    				IFat fat = player.getCapability(FatProvider.Fat_CAP, null);
    				int bellyFatModifier = fat.getThickness();
    				//if(render != null) render.thickness = bellyFatModifier / 2;
    				if((bellyFatModifier / 2) > 0){
    					if(player.isAirBorne == true && Count == 0) {
    						jumpCount = jumpCount + 1;
    						//t.scheduleAtFixedRate(tt, 1000l, 1000l);
    						Count = 1;
    					}
    					if(player.isAirBorne == false) {
    						//time = 0;
    						Count = 0;
    					}
    					if(jumpCount == 20) {
    						fat.removeThickness(2);
    						jumpCount = 0;
    					}
    				}
    				if((bellyFatModifier / 2) > 12) {
    					player.addPotionEffect(effect3);
    					if(oneCount == 0) {
    						player.addPotionEffect(effect5);
    						oneCount = 1;
    					}
    					if(player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() != null){
							player.addItemStackToInventory(player.getItemStackFromSlot(EntityEquipmentSlot.CHEST));
							player.setItemStackToSlot(EntityEquipmentSlot.CHEST, ItemStack.EMPTY);
						}
    					if(player.isRiding())
    						player.dismountRidingEntity();
    					//for(int i = 0; 4 > i; i++) {
    						//if(!(player.inventory.armorInventory.get(i) == ItemStack.EMPTY) && !player.inventory.armorInventory.contains(null)) {
    						//	player.dropItem(player.inventory.armorInventory.get(i).getItem(), 1);
    							//player.inventory.mainInventory.add(player.inventory.armorInventory.get(i));
    	    					//player.inventory.armorInventory.remove(i);
    						//}
    					//}
    				}else if((bellyFatModifier / 2) > 8 && (bellyFatModifier / 2) < 13) {
    					player.addPotionEffect(effect2);
    					if(oneCount == 0) {
    						player.addPotionEffect(effect4);
    						oneCount = 1;
    					}
    					if(player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() != null){
							player.addItemStackToInventory(player.getItemStackFromSlot(EntityEquipmentSlot.CHEST));
							player.setItemStackToSlot(EntityEquipmentSlot.CHEST, ItemStack.EMPTY);
						}
    					if(player.isRiding())
    						player.dismountRidingEntity();
    				}else if((bellyFatModifier / 2) > 5 && (bellyFatModifier / 2) < 9) {
    					player.addPotionEffect(effect1);
    					if(player.isRiding())
    						player.dismountRidingEntity();
    				}else {
    					player.removePotionEffect(MobEffects.SLOWNESS);
    					player.removePotionEffect(MobEffects.ABSORPTION);
    				}
    			}
			}
    	}
	}
	@SubscribeEvent
	public void tick(TickEvent.PlayerTickEvent e) {
		PotionEffect effect1 = new PotionEffect(MobEffects.SLOWNESS, 40, 0);
    	PotionEffect effect2 = new PotionEffect(MobEffects.SLOWNESS, 40, 1);
    	PotionEffect effect3 = new PotionEffect(MobEffects.SLOWNESS, 40, 2);
    	
    	PotionEffect effect4 = new PotionEffect(MobEffects.ABSORPTION, 500, 0);
    	PotionEffect effect5 = new PotionEffect(MobEffects.ABSORPTION, 600, 1);
    	if(overeatingmodel.logged == true) {// && !e.player.world.isRemote){
    		EntityPlayer player = e.player;
    		if(player.hasCapability(FatProvider.Fat_CAP, null)) {
    				IFat fat = player.getCapability(FatProvider.Fat_CAP, null);
    				int bellyFatModifier = fat.getThickness();
    				//if(render != null) render.thickness = bellyFatModifier / 2;
    				if((bellyFatModifier / 2) > 0){
    					if(player.isAirBorne == true && Count == 0) {
    						jumpCount = jumpCount + 1;
    						//t.scheduleAtFixedRate(tt, 1000l, 1000l);
    						Count = 1;
    					}
    					if(player.isAirBorne == false) {
    						//time = 0;
    						Count = 0;
    					}
    					if(jumpCount == 20) {
    						fat.removeThickness(2);
    						jumpCount = 0;
    					}
    				}
    				if((bellyFatModifier / 2) > 12) {
    					player.addPotionEffect(effect3);
    					if(oneCount == 0) {
    						player.addPotionEffect(effect5);
    						oneCount = 1;
    					}
    					if(player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() != null){
							player.addItemStackToInventory(player.getItemStackFromSlot(EntityEquipmentSlot.CHEST));
							player.setItemStackToSlot(EntityEquipmentSlot.CHEST, ItemStack.EMPTY);
						}
    					if(player.isRiding())
    						player.dismountRidingEntity();
    					//for(int i = 0; 4 > i; i++) {
    						//if(!(player.inventory.armorInventory.get(i) == ItemStack.EMPTY) && !player.inventory.armorInventory.contains(null)) {
    						//	player.dropItem(player.inventory.armorInventory.get(i).getItem(), 1);
    							//player.inventory.mainInventory.add(player.inventory.armorInventory.get(i));
    	    					//player.inventory.armorInventory.remove(i);
    						//}
    					//}
    				}else if((bellyFatModifier / 2) > 8 && (bellyFatModifier / 2) < 13) {
    					player.addPotionEffect(effect2);
    					if(oneCount == 0) {
    						player.addPotionEffect(effect4);
    						oneCount = 1;
    					}
    					if(player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() != null){
							player.addItemStackToInventory(player.getItemStackFromSlot(EntityEquipmentSlot.CHEST));
							player.setItemStackToSlot(EntityEquipmentSlot.CHEST, ItemStack.EMPTY);
						}
    					if(player.isRiding())
    						player.dismountRidingEntity();
    				}else if((bellyFatModifier / 2) > 5 && (bellyFatModifier / 2) < 9) {
    					player.addPotionEffect(effect1);
    					if(player.isRiding())
    						player.dismountRidingEntity();
    				}else {
    					player.removePotionEffect(MobEffects.SLOWNESS);
    					player.removePotionEffect(MobEffects.ABSORPTION);
    				}
    			}
			}
	}
	//@SubscribeEvent
	@SuppressWarnings("null")
	public void tick(TickEvent.ServerTickEvent e) {
		PotionEffect effect1 = new PotionEffect(MobEffects.SLOWNESS, 40, 0);
    	PotionEffect effect2 = new PotionEffect(MobEffects.SLOWNESS, 40, 1);
    	PotionEffect effect3 = new PotionEffect(MobEffects.SLOWNESS, 40, 2);
    	
    	PotionEffect effect4 = new PotionEffect(MobEffects.ABSORPTION, 500, 0);
    	PotionEffect effect5 = new PotionEffect(MobEffects.ABSORPTION, 600, 1);
    	if(overeatingmodel.logged == true) {// && !e.player.world.isRemote){
    		EntityPlayer player = null;
    		if(player.hasCapability(FatProvider.Fat_CAP, null)) {
    				IFat fat = player.getCapability(FatProvider.Fat_CAP, null);
    				int bellyFatModifier = fat.getThickness();
    				//if(render != null) render.thickness = bellyFatModifier / 2;
    				if((bellyFatModifier / 2) > 0){
    					if(player.isAirBorne == true && Count == 0) {
    						jumpCount = jumpCount + 1;
    						//t.scheduleAtFixedRate(tt, 1000l, 1000l);
    						Count = 1;
    					}
    					if(player.isAirBorne == false) {
    						//time = 0;
    						Count = 0;
    					}
    					if(jumpCount == 20) {
    						fat.removeThickness(2);
    						jumpCount = 0;
    					}
    				}
    				if((bellyFatModifier / 2) > 12) {
    					player.addPotionEffect(effect3);
    					if(oneCount == 0) {
    						player.addPotionEffect(effect5);
    						oneCount = 1;
    					}
    					if(player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() != null){
							player.addItemStackToInventory(player.getItemStackFromSlot(EntityEquipmentSlot.CHEST));
							player.setItemStackToSlot(EntityEquipmentSlot.CHEST, ItemStack.EMPTY);
						}
    					if(player.isRiding())
    						player.dismountRidingEntity();
    					//for(int i = 0; 4 > i; i++) {
    						//if(!(player.inventory.armorInventory.get(i) == ItemStack.EMPTY) && !player.inventory.armorInventory.contains(null)) {
    						//	player.dropItem(player.inventory.armorInventory.get(i).getItem(), 1);
    							//player.inventory.mainInventory.add(player.inventory.armorInventory.get(i));
    	    					//player.inventory.armorInventory.remove(i);
    						//}
    					//}
    				}else if((bellyFatModifier / 2) > 8 && (bellyFatModifier / 2) < 13) {
    					player.addPotionEffect(effect2);
    					if(oneCount == 0) {
    						player.addPotionEffect(effect4);
    						oneCount = 1;
    					}
    					if(player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() != null){
							player.addItemStackToInventory(player.getItemStackFromSlot(EntityEquipmentSlot.CHEST));
							player.setItemStackToSlot(EntityEquipmentSlot.CHEST, ItemStack.EMPTY);
						}
    					if(player.isRiding())
    						player.dismountRidingEntity();
    				}else if((bellyFatModifier / 2) > 5 && (bellyFatModifier / 2) < 9) {
    					player.addPotionEffect(effect1);
    					if(player.isRiding())
    						player.dismountRidingEntity();
    				}else {
    					player.removePotionEffect(MobEffects.SLOWNESS);
    					player.removePotionEffect(MobEffects.ABSORPTION);
    				}
    			}
			}
	}
	@SubscribeEvent	
	public void itemClickEvent(RightClickItem e) {
    		if(e.getItemStack().getItem() instanceof ItemFood) {
    		((ItemFood)e.getItemStack().getItem()).setAlwaysEdible();
    	//
    		}
    	//else if(e.getItemStack().getItem() instanceof ItemArmor) {
    	//	e.getEntityPlayer().inventory.armorInventory.clear();
    	//	//((ItemArmor)e.getItemStack().getItem()).is
    	//}
    }
    @SubscribeEvent	
	public void itemUseEvent(LivingEntityUseItemEvent.Finish e) {
    	if(e.getItem().getItem() instanceof ItemFood) {
    		if(e.getEntityLiving() instanceof EntityPlayer) {
    			IFat fat = e.getEntityLiving().getCapability(FatProvider.Fat_CAP, null);
    			if(((EntityPlayer)e.getEntityLiving()).getFoodStats().needFood() == false) {
    				fat.addThickness(1);
    				if(((ItemFood)e.getItem().getItem()).getSaturationModifier(e.getItem()) > 0.8F && (fat.getThickness() / 2) > 8)
    				((EntityPlayer)e.getEntityLiving()).getFoodStats().setFoodSaturationLevel(((EntityPlayer)e.getEntityLiving()).getFoodStats().getSaturationLevel() - 0.45F);
    				oneCount = 0;
    			}
    		}
    	}
    }
    @SubscribeEvent
	public void onKnockBack(LivingKnockBackEvent e)
	{
    	if(e.getEntityLiving() instanceof EntityPlayer) {
    		IFat fat = e.getEntityLiving().getCapability(FatProvider.Fat_CAP, null);
    		if((fat.getThickness() / 2) > 12) {
    			e.setStrength(e.getOriginalStrength() - 0.25F);
    		}else if((fat.getThickness() / 2) > 8 && (fat.getThickness() / 2) < 13) {
    			e.setStrength(e.getOriginalStrength() - 0.15F);
    		}
    	}
	}
    @SubscribeEvent
	public void onFall(LivingFallEvent e)
	{
    	if(e.getEntityLiving() instanceof EntityPlayer) {
    		IFat fat = e.getEntityLiving().getCapability(FatProvider.Fat_CAP, null);
    		if((fat.getThickness() / 2) > 12) {
    			e.setDamageMultiplier(e.getDamageMultiplier() + 0.75F);
    		}else if((fat.getThickness() / 2) > 8 && (fat.getThickness() / 2) < 13) {
    			e.setDamageMultiplier(e.getDamageMultiplier() + 0.5F);
    		}
    	}
	}
}

